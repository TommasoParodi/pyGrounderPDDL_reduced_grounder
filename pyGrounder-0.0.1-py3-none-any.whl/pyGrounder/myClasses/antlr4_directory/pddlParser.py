# Generated from pddl.g4 by ANTLR 4.11.1
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,46,538,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,26,
        2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,31,2,32,7,32,2,33,
        7,33,1,0,1,0,3,0,71,8,0,1,1,1,1,1,1,1,1,3,1,77,8,1,1,1,3,1,80,8,
        1,1,1,3,1,83,8,1,1,1,3,1,86,8,1,1,1,5,1,89,8,1,10,1,12,1,92,9,1,
        1,1,1,1,1,2,1,2,1,2,1,2,1,2,1,3,1,3,1,3,4,3,104,8,3,11,3,12,3,105,
        1,3,1,3,1,4,1,4,1,4,1,4,1,4,3,4,115,8,4,4,4,117,8,4,11,4,12,4,118,
        1,4,1,4,1,5,1,5,1,5,4,5,126,8,5,11,5,12,5,127,1,5,1,5,1,6,1,6,1,
        6,5,6,135,8,6,10,6,12,6,138,9,6,1,6,1,6,1,7,1,7,1,7,4,7,145,8,7,
        11,7,12,7,146,1,7,1,7,1,8,1,8,1,8,1,8,1,9,1,9,1,9,4,9,158,8,9,11,
        9,12,9,159,1,9,1,9,1,10,1,10,1,10,5,10,167,8,10,10,10,12,10,170,
        9,10,1,10,1,10,1,11,1,11,5,11,176,8,11,10,11,12,11,179,9,11,1,12,
        1,12,1,12,3,12,184,8,12,1,13,1,13,1,13,1,13,1,13,1,13,5,13,192,8,
        13,10,13,12,13,195,9,13,1,13,1,13,3,13,199,8,13,1,13,3,13,202,8,
        13,1,13,1,13,1,14,1,14,1,14,1,14,5,14,210,8,14,10,14,12,14,213,9,
        14,1,14,1,14,1,15,1,15,1,15,1,15,1,15,3,15,222,8,15,1,16,1,16,1,
        16,1,16,4,16,228,8,16,11,16,12,16,229,1,16,1,16,1,17,1,17,1,17,1,
        17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,
        17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,
        17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,
        17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,
        17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,
        17,3,17,303,8,17,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,
        18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,
        18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,
        18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,
        18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,
        18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,
        18,1,18,1,18,3,18,382,8,18,1,19,1,19,1,19,1,19,1,19,1,19,5,19,390,
        8,19,10,19,12,19,393,9,19,1,19,1,19,3,19,397,8,19,1,19,3,19,400,
        8,19,1,19,1,19,1,20,1,20,1,20,1,20,1,20,1,20,5,20,410,8,20,10,20,
        12,20,413,9,20,1,20,1,20,3,20,417,8,20,1,20,3,20,420,8,20,1,20,1,
        20,1,21,1,21,1,21,1,21,1,21,3,21,429,8,21,1,21,1,21,1,21,3,21,434,
        8,21,1,21,1,21,1,22,1,22,1,22,1,22,1,22,1,23,1,23,1,23,1,23,1,23,
        1,24,1,24,1,24,4,24,451,8,24,11,24,12,24,452,1,24,1,24,1,25,4,25,
        458,8,25,11,25,12,25,459,1,25,1,25,1,25,1,26,1,26,1,26,5,26,468,
        8,26,10,26,12,26,471,9,26,1,26,1,26,1,27,1,27,3,27,477,8,27,1,28,
        1,28,1,28,1,28,1,28,1,28,3,28,485,8,28,1,29,1,29,4,29,489,8,29,11,
        29,12,29,490,1,29,1,29,1,30,1,30,1,30,1,30,1,30,1,30,1,31,1,31,1,
        31,1,31,1,31,4,31,506,8,31,11,31,12,31,507,1,31,1,31,1,31,1,32,1,
        32,1,32,1,32,1,32,1,32,1,32,1,32,1,32,1,32,4,32,523,8,32,11,32,12,
        32,524,1,32,1,32,1,32,3,32,530,8,32,1,33,1,33,1,33,1,33,1,33,1,33,
        1,33,0,0,34,0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,32,34,36,
        38,40,42,44,46,48,50,52,54,56,58,60,62,64,66,0,3,3,0,1,2,5,14,46,
        46,2,0,5,6,8,10,1,0,20,21,562,0,70,1,0,0,0,2,72,1,0,0,0,4,95,1,0,
        0,0,6,100,1,0,0,0,8,109,1,0,0,0,10,122,1,0,0,0,12,131,1,0,0,0,14,
        141,1,0,0,0,16,150,1,0,0,0,18,154,1,0,0,0,20,163,1,0,0,0,22,173,
        1,0,0,0,24,183,1,0,0,0,26,185,1,0,0,0,28,205,1,0,0,0,30,221,1,0,
        0,0,32,223,1,0,0,0,34,302,1,0,0,0,36,381,1,0,0,0,38,383,1,0,0,0,
        40,403,1,0,0,0,42,423,1,0,0,0,44,437,1,0,0,0,46,442,1,0,0,0,48,447,
        1,0,0,0,50,457,1,0,0,0,52,464,1,0,0,0,54,476,1,0,0,0,56,484,1,0,
        0,0,58,486,1,0,0,0,60,494,1,0,0,0,62,500,1,0,0,0,64,529,1,0,0,0,
        66,531,1,0,0,0,68,71,3,2,1,0,69,71,3,42,21,0,70,68,1,0,0,0,70,69,
        1,0,0,0,71,1,1,0,0,0,72,73,5,22,0,0,73,74,5,26,0,0,74,76,3,4,2,0,
        75,77,3,6,3,0,76,75,1,0,0,0,76,77,1,0,0,0,77,79,1,0,0,0,78,80,3,
        8,4,0,79,78,1,0,0,0,79,80,1,0,0,0,80,82,1,0,0,0,81,83,3,10,5,0,82,
        81,1,0,0,0,82,83,1,0,0,0,83,85,1,0,0,0,84,86,3,18,9,0,85,84,1,0,
        0,0,85,86,1,0,0,0,86,90,1,0,0,0,87,89,3,24,12,0,88,87,1,0,0,0,89,
        92,1,0,0,0,90,88,1,0,0,0,90,91,1,0,0,0,91,93,1,0,0,0,92,90,1,0,0,
        0,93,94,5,23,0,0,94,3,1,0,0,0,95,96,5,22,0,0,96,97,5,28,0,0,97,98,
        5,41,0,0,98,99,5,23,0,0,99,5,1,0,0,0,100,101,5,22,0,0,101,103,5,
        29,0,0,102,104,5,45,0,0,103,102,1,0,0,0,104,105,1,0,0,0,105,103,
        1,0,0,0,105,106,1,0,0,0,106,107,1,0,0,0,107,108,5,23,0,0,108,7,1,
        0,0,0,109,110,5,22,0,0,110,116,5,30,0,0,111,114,5,41,0,0,112,113,
        5,1,0,0,113,115,5,41,0,0,114,112,1,0,0,0,114,115,1,0,0,0,115,117,
        1,0,0,0,116,111,1,0,0,0,117,118,1,0,0,0,118,116,1,0,0,0,118,119,
        1,0,0,0,119,120,1,0,0,0,120,121,5,23,0,0,121,9,1,0,0,0,122,123,5,
        22,0,0,123,125,5,31,0,0,124,126,3,12,6,0,125,124,1,0,0,0,126,127,
        1,0,0,0,127,125,1,0,0,0,127,128,1,0,0,0,128,129,1,0,0,0,129,130,
        5,23,0,0,130,11,1,0,0,0,131,132,5,22,0,0,132,136,5,41,0,0,133,135,
        3,16,8,0,134,133,1,0,0,0,135,138,1,0,0,0,136,134,1,0,0,0,136,137,
        1,0,0,0,137,139,1,0,0,0,138,136,1,0,0,0,139,140,5,23,0,0,140,13,
        1,0,0,0,141,142,5,22,0,0,142,144,5,41,0,0,143,145,3,16,8,0,144,143,
        1,0,0,0,145,146,1,0,0,0,146,144,1,0,0,0,146,147,1,0,0,0,147,148,
        1,0,0,0,148,149,5,23,0,0,149,15,1,0,0,0,150,151,5,42,0,0,151,152,
        5,1,0,0,152,153,5,41,0,0,153,17,1,0,0,0,154,155,5,22,0,0,155,157,
        5,32,0,0,156,158,3,20,10,0,157,156,1,0,0,0,158,159,1,0,0,0,159,157,
        1,0,0,0,159,160,1,0,0,0,160,161,1,0,0,0,161,162,5,23,0,0,162,19,
        1,0,0,0,163,164,5,22,0,0,164,168,5,41,0,0,165,167,3,16,8,0,166,165,
        1,0,0,0,167,170,1,0,0,0,168,166,1,0,0,0,168,169,1,0,0,0,169,171,
        1,0,0,0,170,168,1,0,0,0,171,172,5,23,0,0,172,21,1,0,0,0,173,177,
        5,41,0,0,174,176,5,42,0,0,175,174,1,0,0,0,176,179,1,0,0,0,177,175,
        1,0,0,0,177,178,1,0,0,0,178,23,1,0,0,0,179,177,1,0,0,0,180,184,3,
        26,13,0,181,184,3,38,19,0,182,184,3,40,20,0,183,180,1,0,0,0,183,
        181,1,0,0,0,183,182,1,0,0,0,184,25,1,0,0,0,185,186,5,22,0,0,186,
        187,5,33,0,0,187,188,5,41,0,0,188,189,5,34,0,0,189,193,5,22,0,0,
        190,192,3,16,8,0,191,190,1,0,0,0,192,195,1,0,0,0,193,191,1,0,0,0,
        193,194,1,0,0,0,194,196,1,0,0,0,195,193,1,0,0,0,196,198,5,23,0,0,
        197,199,3,28,14,0,198,197,1,0,0,0,198,199,1,0,0,0,199,201,1,0,0,
        0,200,202,3,32,16,0,201,200,1,0,0,0,201,202,1,0,0,0,202,203,1,0,
        0,0,203,204,5,23,0,0,204,27,1,0,0,0,205,206,5,35,0,0,206,207,5,22,
        0,0,207,211,5,2,0,0,208,210,3,30,15,0,209,208,1,0,0,0,210,213,1,
        0,0,0,211,209,1,0,0,0,211,212,1,0,0,0,212,214,1,0,0,0,213,211,1,
        0,0,0,214,215,5,23,0,0,215,29,1,0,0,0,216,217,5,22,0,0,217,218,3,
        22,11,0,218,219,5,23,0,0,219,222,1,0,0,0,220,222,3,36,18,0,221,216,
        1,0,0,0,221,220,1,0,0,0,222,31,1,0,0,0,223,224,5,36,0,0,224,225,
        5,22,0,0,225,227,5,2,0,0,226,228,3,34,17,0,227,226,1,0,0,0,228,229,
        1,0,0,0,229,227,1,0,0,0,229,230,1,0,0,0,230,231,1,0,0,0,231,232,
        5,23,0,0,232,33,1,0,0,0,233,234,5,22,0,0,234,235,3,22,11,0,235,236,
        5,23,0,0,236,303,1,0,0,0,237,238,5,22,0,0,238,239,5,3,0,0,239,240,
        5,22,0,0,240,241,3,22,11,0,241,242,5,23,0,0,242,243,5,23,0,0,243,
        303,1,0,0,0,244,245,5,22,0,0,245,246,5,4,0,0,246,247,5,22,0,0,247,
        248,3,22,11,0,248,249,5,23,0,0,249,250,5,43,0,0,250,251,5,23,0,0,
        251,303,1,0,0,0,252,253,5,22,0,0,253,254,5,39,0,0,254,255,5,22,0,
        0,255,256,3,22,11,0,256,257,5,23,0,0,257,258,5,43,0,0,258,259,5,
        23,0,0,259,303,1,0,0,0,260,261,5,22,0,0,261,262,5,40,0,0,262,263,
        5,22,0,0,263,264,3,22,11,0,264,265,5,23,0,0,265,266,5,43,0,0,266,
        267,5,23,0,0,267,303,1,0,0,0,268,269,5,22,0,0,269,270,5,4,0,0,270,
        271,5,22,0,0,271,272,3,22,11,0,272,273,5,23,0,0,273,274,3,36,18,
        0,274,275,5,23,0,0,275,303,1,0,0,0,276,277,5,22,0,0,277,278,5,39,
        0,0,278,279,5,22,0,0,279,280,3,22,11,0,280,281,5,23,0,0,281,282,
        3,36,18,0,282,283,5,23,0,0,283,303,1,0,0,0,284,285,5,22,0,0,285,
        286,5,40,0,0,286,287,5,22,0,0,287,288,3,22,11,0,288,289,5,23,0,0,
        289,290,3,36,18,0,290,291,5,23,0,0,291,303,1,0,0,0,292,293,5,22,
        0,0,293,294,5,4,0,0,294,295,5,22,0,0,295,296,3,22,11,0,296,297,5,
        23,0,0,297,298,5,22,0,0,298,299,3,22,11,0,299,300,5,23,0,0,300,301,
        5,23,0,0,301,303,1,0,0,0,302,233,1,0,0,0,302,237,1,0,0,0,302,244,
        1,0,0,0,302,252,1,0,0,0,302,260,1,0,0,0,302,268,1,0,0,0,302,276,
        1,0,0,0,302,284,1,0,0,0,302,292,1,0,0,0,303,35,1,0,0,0,304,305,5,
        22,0,0,305,306,7,0,0,0,306,307,5,22,0,0,307,308,3,22,11,0,308,309,
        5,23,0,0,309,310,5,43,0,0,310,311,5,23,0,0,311,382,1,0,0,0,312,313,
        5,22,0,0,313,314,7,0,0,0,314,315,5,43,0,0,315,316,5,22,0,0,316,317,
        3,22,11,0,317,318,5,23,0,0,318,319,5,23,0,0,319,382,1,0,0,0,320,
        321,5,22,0,0,321,322,7,0,0,0,322,323,5,43,0,0,323,324,5,43,0,0,324,
        382,5,23,0,0,325,326,5,22,0,0,326,327,7,0,0,0,327,328,5,22,0,0,328,
        329,3,22,11,0,329,330,5,23,0,0,330,331,5,22,0,0,331,332,3,22,11,
        0,332,333,5,23,0,0,333,334,5,23,0,0,334,382,1,0,0,0,335,336,5,22,
        0,0,336,337,7,0,0,0,337,338,5,22,0,0,338,339,3,22,11,0,339,340,5,
        23,0,0,340,341,3,36,18,0,341,342,5,23,0,0,342,382,1,0,0,0,343,344,
        5,22,0,0,344,345,7,0,0,0,345,346,3,36,18,0,346,347,5,22,0,0,347,
        348,3,22,11,0,348,349,5,23,0,0,349,350,5,23,0,0,350,382,1,0,0,0,
        351,352,5,22,0,0,352,353,7,0,0,0,353,354,5,43,0,0,354,355,3,36,18,
        0,355,356,5,23,0,0,356,382,1,0,0,0,357,358,5,22,0,0,358,359,7,0,
        0,0,359,360,3,36,18,0,360,361,3,36,18,0,361,362,5,23,0,0,362,382,
        1,0,0,0,363,364,5,22,0,0,364,365,7,0,0,0,365,366,3,36,18,0,366,367,
        5,43,0,0,367,368,5,23,0,0,368,382,1,0,0,0,369,370,5,22,0,0,370,371,
        5,3,0,0,371,372,3,36,18,0,372,373,5,23,0,0,373,382,1,0,0,0,374,375,
        5,22,0,0,375,376,5,3,0,0,376,377,5,22,0,0,377,378,3,22,11,0,378,
        379,5,23,0,0,379,380,5,23,0,0,380,382,1,0,0,0,381,304,1,0,0,0,381,
        312,1,0,0,0,381,320,1,0,0,0,381,325,1,0,0,0,381,335,1,0,0,0,381,
        343,1,0,0,0,381,351,1,0,0,0,381,357,1,0,0,0,381,363,1,0,0,0,381,
        369,1,0,0,0,381,374,1,0,0,0,382,37,1,0,0,0,383,384,5,22,0,0,384,
        385,5,37,0,0,385,386,5,41,0,0,386,387,5,34,0,0,387,391,5,22,0,0,
        388,390,3,16,8,0,389,388,1,0,0,0,390,393,1,0,0,0,391,389,1,0,0,0,
        391,392,1,0,0,0,392,394,1,0,0,0,393,391,1,0,0,0,394,396,5,23,0,0,
        395,397,3,28,14,0,396,395,1,0,0,0,396,397,1,0,0,0,397,399,1,0,0,
        0,398,400,3,32,16,0,399,398,1,0,0,0,399,400,1,0,0,0,400,401,1,0,
        0,0,401,402,5,23,0,0,402,39,1,0,0,0,403,404,5,22,0,0,404,405,5,38,
        0,0,405,406,5,41,0,0,406,407,5,34,0,0,407,411,5,22,0,0,408,410,3,
        16,8,0,409,408,1,0,0,0,410,413,1,0,0,0,411,409,1,0,0,0,411,412,1,
        0,0,0,412,414,1,0,0,0,413,411,1,0,0,0,414,416,5,23,0,0,415,417,3,
        28,14,0,416,415,1,0,0,0,416,417,1,0,0,0,417,419,1,0,0,0,418,420,
        3,32,16,0,419,418,1,0,0,0,419,420,1,0,0,0,420,421,1,0,0,0,421,422,
        5,23,0,0,422,41,1,0,0,0,423,424,5,22,0,0,424,425,5,26,0,0,425,426,
        3,44,22,0,426,428,3,46,23,0,427,429,3,48,24,0,428,427,1,0,0,0,428,
        429,1,0,0,0,429,430,1,0,0,0,430,431,3,52,26,0,431,433,3,62,31,0,
        432,434,3,66,33,0,433,432,1,0,0,0,433,434,1,0,0,0,434,435,1,0,0,
        0,435,436,5,23,0,0,436,43,1,0,0,0,437,438,5,22,0,0,438,439,5,27,
        0,0,439,440,5,41,0,0,440,441,5,23,0,0,441,45,1,0,0,0,442,443,5,22,
        0,0,443,444,5,15,0,0,444,445,5,41,0,0,445,446,5,23,0,0,446,47,1,
        0,0,0,447,448,5,22,0,0,448,450,5,16,0,0,449,451,3,50,25,0,450,449,
        1,0,0,0,451,452,1,0,0,0,452,450,1,0,0,0,452,453,1,0,0,0,453,454,
        1,0,0,0,454,455,5,23,0,0,455,49,1,0,0,0,456,458,5,41,0,0,457,456,
        1,0,0,0,458,459,1,0,0,0,459,457,1,0,0,0,459,460,1,0,0,0,460,461,
        1,0,0,0,461,462,5,1,0,0,462,463,5,41,0,0,463,51,1,0,0,0,464,465,
        5,22,0,0,465,469,5,17,0,0,466,468,3,54,27,0,467,466,1,0,0,0,468,
        471,1,0,0,0,469,467,1,0,0,0,469,470,1,0,0,0,470,472,1,0,0,0,471,
        469,1,0,0,0,472,473,5,23,0,0,473,53,1,0,0,0,474,477,3,56,28,0,475,
        477,3,60,30,0,476,474,1,0,0,0,476,475,1,0,0,0,477,55,1,0,0,0,478,
        485,3,58,29,0,479,480,5,22,0,0,480,481,5,3,0,0,481,482,3,58,29,0,
        482,483,5,23,0,0,483,485,1,0,0,0,484,478,1,0,0,0,484,479,1,0,0,0,
        485,57,1,0,0,0,486,488,5,22,0,0,487,489,5,41,0,0,488,487,1,0,0,0,
        489,490,1,0,0,0,490,488,1,0,0,0,490,491,1,0,0,0,491,492,1,0,0,0,
        492,493,5,23,0,0,493,59,1,0,0,0,494,495,5,22,0,0,495,496,5,5,0,0,
        496,497,3,58,29,0,497,498,5,43,0,0,498,499,5,23,0,0,499,61,1,0,0,
        0,500,501,5,22,0,0,501,502,5,18,0,0,502,503,5,22,0,0,503,505,5,2,
        0,0,504,506,3,64,32,0,505,504,1,0,0,0,506,507,1,0,0,0,507,505,1,
        0,0,0,507,508,1,0,0,0,508,509,1,0,0,0,509,510,5,23,0,0,510,511,5,
        23,0,0,511,63,1,0,0,0,512,530,3,58,29,0,513,514,5,22,0,0,514,515,
        5,3,0,0,515,516,3,58,29,0,516,517,5,23,0,0,517,530,1,0,0,0,518,519,
        5,22,0,0,519,520,7,1,0,0,520,522,5,22,0,0,521,523,5,41,0,0,522,521,
        1,0,0,0,523,524,1,0,0,0,524,522,1,0,0,0,524,525,1,0,0,0,525,526,
        1,0,0,0,526,527,5,23,0,0,527,528,5,43,0,0,528,530,5,23,0,0,529,512,
        1,0,0,0,529,513,1,0,0,0,529,518,1,0,0,0,530,65,1,0,0,0,531,532,5,
        22,0,0,532,533,5,19,0,0,533,534,7,2,0,0,534,535,3,58,29,0,535,536,
        5,23,0,0,536,67,1,0,0,0,41,70,76,79,82,85,90,105,114,118,127,136,
        146,159,168,177,183,193,198,201,211,221,229,302,381,391,396,399,
        411,416,419,428,433,452,459,469,476,484,490,507,524,529
    ]

class pddlParser ( Parser ):

    grammarFileName = "pddl.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'-'", "'and'", "'not'", "'assign'", "'='", 
                     "'<'", "'=<'", "'<='", "'>='", "'>'", "'+'", "'*'", 
                     "'/'", "'or'", "':domain'", "':objects'", "':init'", 
                     "':goal'", "':metric'", "'maximize'", "'minimize'", 
                     "'('", "')'", "'\"'", "','", "'define'", "'problem'", 
                     "'domain'", "':requirements'", "':types'", "':predicates'", 
                     "':functions'", "':action'", "':parameters'", "':precondition'", 
                     "':effect'", "':process'", "':event'", "'increase'", 
                     "'decrease'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "LP", "RP", "QUOTE", "COMMA", 
                      "DEFINE", "PROBLEM", "DOMAIN", "REQUIREMENTS", "TYPES", 
                      "PREDICATES", "FUNCTIONS", "ACTION", "PARAMETERS", 
                      "PRECONDITION", "EFFECT", "PROCESS", "EVENT", "INCREASE", 
                      "DECREASE", "NAME", "VARIABLE", "NUMBER", "WS", "REQUIRE_KEY", 
                      "OPERATION" ]

    RULE_pddlDoc = 0
    RULE_domain = 1
    RULE_domainName = 2
    RULE_requireDef = 3
    RULE_typesDef = 4
    RULE_predicatesDef = 5
    RULE_predicate = 6
    RULE_atomicFormulaSkeleton = 7
    RULE_typedVariable = 8
    RULE_functionsDef = 9
    RULE_function = 10
    RULE_predicatedVariables = 11
    RULE_structureDef = 12
    RULE_actionDef = 13
    RULE_precondition = 14
    RULE_precondition_formula = 15
    RULE_effect = 16
    RULE_effect_formula = 17
    RULE_operation = 18
    RULE_processDef = 19
    RULE_eventDef = 20
    RULE_problem = 21
    RULE_problemDecl = 22
    RULE_problemDomain = 23
    RULE_objectDecl = 24
    RULE_sameTypeNamesList = 25
    RULE_init = 26
    RULE_initEl = 27
    RULE_nameLiteral = 28
    RULE_atomicNameFormula = 29
    RULE_equalLiteral = 30
    RULE_goal = 31
    RULE_goalDesc = 32
    RULE_metric = 33

    ruleNames =  [ "pddlDoc", "domain", "domainName", "requireDef", "typesDef", 
                   "predicatesDef", "predicate", "atomicFormulaSkeleton", 
                   "typedVariable", "functionsDef", "function", "predicatedVariables", 
                   "structureDef", "actionDef", "precondition", "precondition_formula", 
                   "effect", "effect_formula", "operation", "processDef", 
                   "eventDef", "problem", "problemDecl", "problemDomain", 
                   "objectDecl", "sameTypeNamesList", "init", "initEl", 
                   "nameLiteral", "atomicNameFormula", "equalLiteral", "goal", 
                   "goalDesc", "metric" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    T__11=12
    T__12=13
    T__13=14
    T__14=15
    T__15=16
    T__16=17
    T__17=18
    T__18=19
    T__19=20
    T__20=21
    LP=22
    RP=23
    QUOTE=24
    COMMA=25
    DEFINE=26
    PROBLEM=27
    DOMAIN=28
    REQUIREMENTS=29
    TYPES=30
    PREDICATES=31
    FUNCTIONS=32
    ACTION=33
    PARAMETERS=34
    PRECONDITION=35
    EFFECT=36
    PROCESS=37
    EVENT=38
    INCREASE=39
    DECREASE=40
    NAME=41
    VARIABLE=42
    NUMBER=43
    WS=44
    REQUIRE_KEY=45
    OPERATION=46

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.11.1")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class PddlDocContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def domain(self):
            return self.getTypedRuleContext(pddlParser.DomainContext,0)


        def problem(self):
            return self.getTypedRuleContext(pddlParser.ProblemContext,0)


        def getRuleIndex(self):
            return pddlParser.RULE_pddlDoc

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPddlDoc" ):
                listener.enterPddlDoc(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPddlDoc" ):
                listener.exitPddlDoc(self)




    def pddlDoc(self):

        localctx = pddlParser.PddlDocContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_pddlDoc)
        try:
            self.state = 70
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,0,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 68
                self.domain()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 69
                self.problem()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DomainContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LP(self):
            return self.getToken(pddlParser.LP, 0)

        def DEFINE(self):
            return self.getToken(pddlParser.DEFINE, 0)

        def domainName(self):
            return self.getTypedRuleContext(pddlParser.DomainNameContext,0)


        def RP(self):
            return self.getToken(pddlParser.RP, 0)

        def requireDef(self):
            return self.getTypedRuleContext(pddlParser.RequireDefContext,0)


        def typesDef(self):
            return self.getTypedRuleContext(pddlParser.TypesDefContext,0)


        def predicatesDef(self):
            return self.getTypedRuleContext(pddlParser.PredicatesDefContext,0)


        def functionsDef(self):
            return self.getTypedRuleContext(pddlParser.FunctionsDefContext,0)


        def structureDef(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(pddlParser.StructureDefContext)
            else:
                return self.getTypedRuleContext(pddlParser.StructureDefContext,i)


        def getRuleIndex(self):
            return pddlParser.RULE_domain

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDomain" ):
                listener.enterDomain(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDomain" ):
                listener.exitDomain(self)




    def domain(self):

        localctx = pddlParser.DomainContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_domain)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 72
            self.match(pddlParser.LP)
            self.state = 73
            self.match(pddlParser.DEFINE)
            self.state = 74
            self.domainName()
            self.state = 76
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
            if la_ == 1:
                self.state = 75
                self.requireDef()


            self.state = 79
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,2,self._ctx)
            if la_ == 1:
                self.state = 78
                self.typesDef()


            self.state = 82
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,3,self._ctx)
            if la_ == 1:
                self.state = 81
                self.predicatesDef()


            self.state = 85
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,4,self._ctx)
            if la_ == 1:
                self.state = 84
                self.functionsDef()


            self.state = 90
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==22:
                self.state = 87
                self.structureDef()
                self.state = 92
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 93
            self.match(pddlParser.RP)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DomainNameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LP(self):
            return self.getToken(pddlParser.LP, 0)

        def DOMAIN(self):
            return self.getToken(pddlParser.DOMAIN, 0)

        def NAME(self):
            return self.getToken(pddlParser.NAME, 0)

        def RP(self):
            return self.getToken(pddlParser.RP, 0)

        def getRuleIndex(self):
            return pddlParser.RULE_domainName

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDomainName" ):
                listener.enterDomainName(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDomainName" ):
                listener.exitDomainName(self)




    def domainName(self):

        localctx = pddlParser.DomainNameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_domainName)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 95
            self.match(pddlParser.LP)
            self.state = 96
            self.match(pddlParser.DOMAIN)
            self.state = 97
            self.match(pddlParser.NAME)
            self.state = 98
            self.match(pddlParser.RP)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RequireDefContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LP(self):
            return self.getToken(pddlParser.LP, 0)

        def REQUIREMENTS(self):
            return self.getToken(pddlParser.REQUIREMENTS, 0)

        def RP(self):
            return self.getToken(pddlParser.RP, 0)

        def REQUIRE_KEY(self, i:int=None):
            if i is None:
                return self.getTokens(pddlParser.REQUIRE_KEY)
            else:
                return self.getToken(pddlParser.REQUIRE_KEY, i)

        def getRuleIndex(self):
            return pddlParser.RULE_requireDef

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRequireDef" ):
                listener.enterRequireDef(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRequireDef" ):
                listener.exitRequireDef(self)




    def requireDef(self):

        localctx = pddlParser.RequireDefContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_requireDef)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 100
            self.match(pddlParser.LP)
            self.state = 101
            self.match(pddlParser.REQUIREMENTS)
            self.state = 103 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 102
                self.match(pddlParser.REQUIRE_KEY)
                self.state = 105 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==45):
                    break

            self.state = 107
            self.match(pddlParser.RP)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TypesDefContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LP(self):
            return self.getToken(pddlParser.LP, 0)

        def TYPES(self):
            return self.getToken(pddlParser.TYPES, 0)

        def RP(self):
            return self.getToken(pddlParser.RP, 0)

        def NAME(self, i:int=None):
            if i is None:
                return self.getTokens(pddlParser.NAME)
            else:
                return self.getToken(pddlParser.NAME, i)

        def getRuleIndex(self):
            return pddlParser.RULE_typesDef

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTypesDef" ):
                listener.enterTypesDef(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTypesDef" ):
                listener.exitTypesDef(self)




    def typesDef(self):

        localctx = pddlParser.TypesDefContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_typesDef)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 109
            self.match(pddlParser.LP)
            self.state = 110
            self.match(pddlParser.TYPES)
            self.state = 116 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 111
                self.match(pddlParser.NAME)
                self.state = 114
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==1:
                    self.state = 112
                    self.match(pddlParser.T__0)
                    self.state = 113
                    self.match(pddlParser.NAME)


                self.state = 118 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==41):
                    break

            self.state = 120
            self.match(pddlParser.RP)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PredicatesDefContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LP(self):
            return self.getToken(pddlParser.LP, 0)

        def PREDICATES(self):
            return self.getToken(pddlParser.PREDICATES, 0)

        def RP(self):
            return self.getToken(pddlParser.RP, 0)

        def predicate(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(pddlParser.PredicateContext)
            else:
                return self.getTypedRuleContext(pddlParser.PredicateContext,i)


        def getRuleIndex(self):
            return pddlParser.RULE_predicatesDef

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPredicatesDef" ):
                listener.enterPredicatesDef(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPredicatesDef" ):
                listener.exitPredicatesDef(self)




    def predicatesDef(self):

        localctx = pddlParser.PredicatesDefContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_predicatesDef)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 122
            self.match(pddlParser.LP)
            self.state = 123
            self.match(pddlParser.PREDICATES)
            self.state = 125 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 124
                self.predicate()
                self.state = 127 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==22):
                    break

            self.state = 129
            self.match(pddlParser.RP)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PredicateContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LP(self):
            return self.getToken(pddlParser.LP, 0)

        def NAME(self):
            return self.getToken(pddlParser.NAME, 0)

        def RP(self):
            return self.getToken(pddlParser.RP, 0)

        def typedVariable(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(pddlParser.TypedVariableContext)
            else:
                return self.getTypedRuleContext(pddlParser.TypedVariableContext,i)


        def getRuleIndex(self):
            return pddlParser.RULE_predicate

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPredicate" ):
                listener.enterPredicate(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPredicate" ):
                listener.exitPredicate(self)




    def predicate(self):

        localctx = pddlParser.PredicateContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_predicate)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 131
            self.match(pddlParser.LP)
            self.state = 132
            self.match(pddlParser.NAME)
            self.state = 136
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==42:
                self.state = 133
                self.typedVariable()
                self.state = 138
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 139
            self.match(pddlParser.RP)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AtomicFormulaSkeletonContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LP(self):
            return self.getToken(pddlParser.LP, 0)

        def NAME(self):
            return self.getToken(pddlParser.NAME, 0)

        def RP(self):
            return self.getToken(pddlParser.RP, 0)

        def typedVariable(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(pddlParser.TypedVariableContext)
            else:
                return self.getTypedRuleContext(pddlParser.TypedVariableContext,i)


        def getRuleIndex(self):
            return pddlParser.RULE_atomicFormulaSkeleton

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAtomicFormulaSkeleton" ):
                listener.enterAtomicFormulaSkeleton(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAtomicFormulaSkeleton" ):
                listener.exitAtomicFormulaSkeleton(self)




    def atomicFormulaSkeleton(self):

        localctx = pddlParser.AtomicFormulaSkeletonContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_atomicFormulaSkeleton)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 141
            self.match(pddlParser.LP)
            self.state = 142
            self.match(pddlParser.NAME)
            self.state = 144 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 143
                self.typedVariable()
                self.state = 146 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==42):
                    break

            self.state = 148
            self.match(pddlParser.RP)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TypedVariableContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def VARIABLE(self):
            return self.getToken(pddlParser.VARIABLE, 0)

        def NAME(self):
            return self.getToken(pddlParser.NAME, 0)

        def getRuleIndex(self):
            return pddlParser.RULE_typedVariable

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTypedVariable" ):
                listener.enterTypedVariable(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTypedVariable" ):
                listener.exitTypedVariable(self)




    def typedVariable(self):

        localctx = pddlParser.TypedVariableContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_typedVariable)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 150
            self.match(pddlParser.VARIABLE)
            self.state = 151
            self.match(pddlParser.T__0)
            self.state = 152
            self.match(pddlParser.NAME)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FunctionsDefContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LP(self):
            return self.getToken(pddlParser.LP, 0)

        def FUNCTIONS(self):
            return self.getToken(pddlParser.FUNCTIONS, 0)

        def RP(self):
            return self.getToken(pddlParser.RP, 0)

        def function(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(pddlParser.FunctionContext)
            else:
                return self.getTypedRuleContext(pddlParser.FunctionContext,i)


        def getRuleIndex(self):
            return pddlParser.RULE_functionsDef

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunctionsDef" ):
                listener.enterFunctionsDef(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunctionsDef" ):
                listener.exitFunctionsDef(self)




    def functionsDef(self):

        localctx = pddlParser.FunctionsDefContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_functionsDef)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 154
            self.match(pddlParser.LP)
            self.state = 155
            self.match(pddlParser.FUNCTIONS)
            self.state = 157 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 156
                self.function()
                self.state = 159 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==22):
                    break

            self.state = 161
            self.match(pddlParser.RP)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FunctionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LP(self):
            return self.getToken(pddlParser.LP, 0)

        def NAME(self):
            return self.getToken(pddlParser.NAME, 0)

        def RP(self):
            return self.getToken(pddlParser.RP, 0)

        def typedVariable(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(pddlParser.TypedVariableContext)
            else:
                return self.getTypedRuleContext(pddlParser.TypedVariableContext,i)


        def getRuleIndex(self):
            return pddlParser.RULE_function

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunction" ):
                listener.enterFunction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunction" ):
                listener.exitFunction(self)




    def function(self):

        localctx = pddlParser.FunctionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_function)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 163
            self.match(pddlParser.LP)
            self.state = 164
            self.match(pddlParser.NAME)
            self.state = 168
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==42:
                self.state = 165
                self.typedVariable()
                self.state = 170
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 171
            self.match(pddlParser.RP)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PredicatedVariablesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NAME(self):
            return self.getToken(pddlParser.NAME, 0)

        def VARIABLE(self, i:int=None):
            if i is None:
                return self.getTokens(pddlParser.VARIABLE)
            else:
                return self.getToken(pddlParser.VARIABLE, i)

        def getRuleIndex(self):
            return pddlParser.RULE_predicatedVariables

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPredicatedVariables" ):
                listener.enterPredicatedVariables(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPredicatedVariables" ):
                listener.exitPredicatedVariables(self)




    def predicatedVariables(self):

        localctx = pddlParser.PredicatedVariablesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_predicatedVariables)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 173
            self.match(pddlParser.NAME)
            self.state = 177
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==42:
                self.state = 174
                self.match(pddlParser.VARIABLE)
                self.state = 179
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StructureDefContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def actionDef(self):
            return self.getTypedRuleContext(pddlParser.ActionDefContext,0)


        def processDef(self):
            return self.getTypedRuleContext(pddlParser.ProcessDefContext,0)


        def eventDef(self):
            return self.getTypedRuleContext(pddlParser.EventDefContext,0)


        def getRuleIndex(self):
            return pddlParser.RULE_structureDef

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStructureDef" ):
                listener.enterStructureDef(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStructureDef" ):
                listener.exitStructureDef(self)




    def structureDef(self):

        localctx = pddlParser.StructureDefContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_structureDef)
        try:
            self.state = 183
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,15,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 180
                self.actionDef()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 181
                self.processDef()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 182
                self.eventDef()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ActionDefContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LP(self, i:int=None):
            if i is None:
                return self.getTokens(pddlParser.LP)
            else:
                return self.getToken(pddlParser.LP, i)

        def ACTION(self):
            return self.getToken(pddlParser.ACTION, 0)

        def NAME(self):
            return self.getToken(pddlParser.NAME, 0)

        def PARAMETERS(self):
            return self.getToken(pddlParser.PARAMETERS, 0)

        def RP(self, i:int=None):
            if i is None:
                return self.getTokens(pddlParser.RP)
            else:
                return self.getToken(pddlParser.RP, i)

        def typedVariable(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(pddlParser.TypedVariableContext)
            else:
                return self.getTypedRuleContext(pddlParser.TypedVariableContext,i)


        def precondition(self):
            return self.getTypedRuleContext(pddlParser.PreconditionContext,0)


        def effect(self):
            return self.getTypedRuleContext(pddlParser.EffectContext,0)


        def getRuleIndex(self):
            return pddlParser.RULE_actionDef

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterActionDef" ):
                listener.enterActionDef(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitActionDef" ):
                listener.exitActionDef(self)




    def actionDef(self):

        localctx = pddlParser.ActionDefContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_actionDef)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 185
            self.match(pddlParser.LP)
            self.state = 186
            self.match(pddlParser.ACTION)
            self.state = 187
            self.match(pddlParser.NAME)
            self.state = 188
            self.match(pddlParser.PARAMETERS)
            self.state = 189
            self.match(pddlParser.LP)
            self.state = 193
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==42:
                self.state = 190
                self.typedVariable()
                self.state = 195
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 196
            self.match(pddlParser.RP)
            self.state = 198
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==35:
                self.state = 197
                self.precondition()


            self.state = 201
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==36:
                self.state = 200
                self.effect()


            self.state = 203
            self.match(pddlParser.RP)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PreconditionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def PRECONDITION(self):
            return self.getToken(pddlParser.PRECONDITION, 0)

        def LP(self):
            return self.getToken(pddlParser.LP, 0)

        def RP(self):
            return self.getToken(pddlParser.RP, 0)

        def precondition_formula(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(pddlParser.Precondition_formulaContext)
            else:
                return self.getTypedRuleContext(pddlParser.Precondition_formulaContext,i)


        def getRuleIndex(self):
            return pddlParser.RULE_precondition

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrecondition" ):
                listener.enterPrecondition(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrecondition" ):
                listener.exitPrecondition(self)




    def precondition(self):

        localctx = pddlParser.PreconditionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_precondition)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 205
            self.match(pddlParser.PRECONDITION)
            self.state = 206
            self.match(pddlParser.LP)
            self.state = 207
            self.match(pddlParser.T__1)
            self.state = 211
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==22:
                self.state = 208
                self.precondition_formula()
                self.state = 213
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 214
            self.match(pddlParser.RP)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Precondition_formulaContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LP(self):
            return self.getToken(pddlParser.LP, 0)

        def predicatedVariables(self):
            return self.getTypedRuleContext(pddlParser.PredicatedVariablesContext,0)


        def RP(self):
            return self.getToken(pddlParser.RP, 0)

        def operation(self):
            return self.getTypedRuleContext(pddlParser.OperationContext,0)


        def getRuleIndex(self):
            return pddlParser.RULE_precondition_formula

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrecondition_formula" ):
                listener.enterPrecondition_formula(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrecondition_formula" ):
                listener.exitPrecondition_formula(self)




    def precondition_formula(self):

        localctx = pddlParser.Precondition_formulaContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_precondition_formula)
        try:
            self.state = 221
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,20,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 216
                self.match(pddlParser.LP)
                self.state = 217
                self.predicatedVariables()
                self.state = 218
                self.match(pddlParser.RP)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 220
                self.operation()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EffectContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EFFECT(self):
            return self.getToken(pddlParser.EFFECT, 0)

        def LP(self):
            return self.getToken(pddlParser.LP, 0)

        def RP(self):
            return self.getToken(pddlParser.RP, 0)

        def effect_formula(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(pddlParser.Effect_formulaContext)
            else:
                return self.getTypedRuleContext(pddlParser.Effect_formulaContext,i)


        def getRuleIndex(self):
            return pddlParser.RULE_effect

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEffect" ):
                listener.enterEffect(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEffect" ):
                listener.exitEffect(self)




    def effect(self):

        localctx = pddlParser.EffectContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_effect)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 223
            self.match(pddlParser.EFFECT)
            self.state = 224
            self.match(pddlParser.LP)
            self.state = 225
            self.match(pddlParser.T__1)
            self.state = 227 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 226
                self.effect_formula()
                self.state = 229 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==22):
                    break

            self.state = 231
            self.match(pddlParser.RP)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Effect_formulaContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LP(self, i:int=None):
            if i is None:
                return self.getTokens(pddlParser.LP)
            else:
                return self.getToken(pddlParser.LP, i)

        def predicatedVariables(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(pddlParser.PredicatedVariablesContext)
            else:
                return self.getTypedRuleContext(pddlParser.PredicatedVariablesContext,i)


        def RP(self, i:int=None):
            if i is None:
                return self.getTokens(pddlParser.RP)
            else:
                return self.getToken(pddlParser.RP, i)

        def NUMBER(self):
            return self.getToken(pddlParser.NUMBER, 0)

        def INCREASE(self):
            return self.getToken(pddlParser.INCREASE, 0)

        def DECREASE(self):
            return self.getToken(pddlParser.DECREASE, 0)

        def operation(self):
            return self.getTypedRuleContext(pddlParser.OperationContext,0)


        def getRuleIndex(self):
            return pddlParser.RULE_effect_formula

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEffect_formula" ):
                listener.enterEffect_formula(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEffect_formula" ):
                listener.exitEffect_formula(self)




    def effect_formula(self):

        localctx = pddlParser.Effect_formulaContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_effect_formula)
        try:
            self.state = 302
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,22,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 233
                self.match(pddlParser.LP)
                self.state = 234
                self.predicatedVariables()
                self.state = 235
                self.match(pddlParser.RP)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 237
                self.match(pddlParser.LP)
                self.state = 238
                self.match(pddlParser.T__2)
                self.state = 239
                self.match(pddlParser.LP)
                self.state = 240
                self.predicatedVariables()
                self.state = 241
                self.match(pddlParser.RP)
                self.state = 242
                self.match(pddlParser.RP)
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 244
                self.match(pddlParser.LP)
                self.state = 245
                self.match(pddlParser.T__3)
                self.state = 246
                self.match(pddlParser.LP)
                self.state = 247
                self.predicatedVariables()
                self.state = 248
                self.match(pddlParser.RP)
                self.state = 249
                self.match(pddlParser.NUMBER)
                self.state = 250
                self.match(pddlParser.RP)
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 252
                self.match(pddlParser.LP)
                self.state = 253
                self.match(pddlParser.INCREASE)
                self.state = 254
                self.match(pddlParser.LP)
                self.state = 255
                self.predicatedVariables()
                self.state = 256
                self.match(pddlParser.RP)
                self.state = 257
                self.match(pddlParser.NUMBER)
                self.state = 258
                self.match(pddlParser.RP)
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 260
                self.match(pddlParser.LP)
                self.state = 261
                self.match(pddlParser.DECREASE)
                self.state = 262
                self.match(pddlParser.LP)
                self.state = 263
                self.predicatedVariables()
                self.state = 264
                self.match(pddlParser.RP)
                self.state = 265
                self.match(pddlParser.NUMBER)
                self.state = 266
                self.match(pddlParser.RP)
                pass

            elif la_ == 6:
                self.enterOuterAlt(localctx, 6)
                self.state = 268
                self.match(pddlParser.LP)
                self.state = 269
                self.match(pddlParser.T__3)
                self.state = 270
                self.match(pddlParser.LP)
                self.state = 271
                self.predicatedVariables()
                self.state = 272
                self.match(pddlParser.RP)
                self.state = 273
                self.operation()
                self.state = 274
                self.match(pddlParser.RP)
                pass

            elif la_ == 7:
                self.enterOuterAlt(localctx, 7)
                self.state = 276
                self.match(pddlParser.LP)
                self.state = 277
                self.match(pddlParser.INCREASE)
                self.state = 278
                self.match(pddlParser.LP)
                self.state = 279
                self.predicatedVariables()
                self.state = 280
                self.match(pddlParser.RP)
                self.state = 281
                self.operation()
                self.state = 282
                self.match(pddlParser.RP)
                pass

            elif la_ == 8:
                self.enterOuterAlt(localctx, 8)
                self.state = 284
                self.match(pddlParser.LP)
                self.state = 285
                self.match(pddlParser.DECREASE)
                self.state = 286
                self.match(pddlParser.LP)
                self.state = 287
                self.predicatedVariables()
                self.state = 288
                self.match(pddlParser.RP)
                self.state = 289
                self.operation()
                self.state = 290
                self.match(pddlParser.RP)
                pass

            elif la_ == 9:
                self.enterOuterAlt(localctx, 9)
                self.state = 292
                self.match(pddlParser.LP)
                self.state = 293
                self.match(pddlParser.T__3)
                self.state = 294
                self.match(pddlParser.LP)
                self.state = 295
                self.predicatedVariables()
                self.state = 296
                self.match(pddlParser.RP)
                self.state = 297
                self.match(pddlParser.LP)
                self.state = 298
                self.predicatedVariables()
                self.state = 299
                self.match(pddlParser.RP)
                self.state = 300
                self.match(pddlParser.RP)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class OperationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LP(self, i:int=None):
            if i is None:
                return self.getTokens(pddlParser.LP)
            else:
                return self.getToken(pddlParser.LP, i)

        def predicatedVariables(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(pddlParser.PredicatedVariablesContext)
            else:
                return self.getTypedRuleContext(pddlParser.PredicatedVariablesContext,i)


        def RP(self, i:int=None):
            if i is None:
                return self.getTokens(pddlParser.RP)
            else:
                return self.getToken(pddlParser.RP, i)

        def NUMBER(self, i:int=None):
            if i is None:
                return self.getTokens(pddlParser.NUMBER)
            else:
                return self.getToken(pddlParser.NUMBER, i)

        def OPERATION(self):
            return self.getToken(pddlParser.OPERATION, 0)

        def operation(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(pddlParser.OperationContext)
            else:
                return self.getTypedRuleContext(pddlParser.OperationContext,i)


        def getRuleIndex(self):
            return pddlParser.RULE_operation

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOperation" ):
                listener.enterOperation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOperation" ):
                listener.exitOperation(self)




    def operation(self):

        localctx = pddlParser.OperationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_operation)
        self._la = 0 # Token type
        try:
            self.state = 381
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,23,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 304
                self.match(pddlParser.LP)
                self.state = 305
                _la = self._input.LA(1)
                if not(((_la) & ~0x3f) == 0 and ((1 << _la) & 70368744210406) != 0):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 306
                self.match(pddlParser.LP)
                self.state = 307
                self.predicatedVariables()
                self.state = 308
                self.match(pddlParser.RP)
                self.state = 309
                self.match(pddlParser.NUMBER)
                self.state = 310
                self.match(pddlParser.RP)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 312
                self.match(pddlParser.LP)
                self.state = 313
                _la = self._input.LA(1)
                if not(((_la) & ~0x3f) == 0 and ((1 << _la) & 70368744210406) != 0):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 314
                self.match(pddlParser.NUMBER)
                self.state = 315
                self.match(pddlParser.LP)
                self.state = 316
                self.predicatedVariables()
                self.state = 317
                self.match(pddlParser.RP)
                self.state = 318
                self.match(pddlParser.RP)
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 320
                self.match(pddlParser.LP)
                self.state = 321
                _la = self._input.LA(1)
                if not(((_la) & ~0x3f) == 0 and ((1 << _la) & 70368744210406) != 0):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 322
                self.match(pddlParser.NUMBER)
                self.state = 323
                self.match(pddlParser.NUMBER)
                self.state = 324
                self.match(pddlParser.RP)
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 325
                self.match(pddlParser.LP)
                self.state = 326
                _la = self._input.LA(1)
                if not(((_la) & ~0x3f) == 0 and ((1 << _la) & 70368744210406) != 0):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 327
                self.match(pddlParser.LP)
                self.state = 328
                self.predicatedVariables()
                self.state = 329
                self.match(pddlParser.RP)
                self.state = 330
                self.match(pddlParser.LP)
                self.state = 331
                self.predicatedVariables()
                self.state = 332
                self.match(pddlParser.RP)
                self.state = 333
                self.match(pddlParser.RP)
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 335
                self.match(pddlParser.LP)
                self.state = 336
                _la = self._input.LA(1)
                if not(((_la) & ~0x3f) == 0 and ((1 << _la) & 70368744210406) != 0):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 337
                self.match(pddlParser.LP)
                self.state = 338
                self.predicatedVariables()
                self.state = 339
                self.match(pddlParser.RP)
                self.state = 340
                self.operation()
                self.state = 341
                self.match(pddlParser.RP)
                pass

            elif la_ == 6:
                self.enterOuterAlt(localctx, 6)
                self.state = 343
                self.match(pddlParser.LP)
                self.state = 344
                _la = self._input.LA(1)
                if not(((_la) & ~0x3f) == 0 and ((1 << _la) & 70368744210406) != 0):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 345
                self.operation()
                self.state = 346
                self.match(pddlParser.LP)
                self.state = 347
                self.predicatedVariables()
                self.state = 348
                self.match(pddlParser.RP)
                self.state = 349
                self.match(pddlParser.RP)
                pass

            elif la_ == 7:
                self.enterOuterAlt(localctx, 7)
                self.state = 351
                self.match(pddlParser.LP)
                self.state = 352
                _la = self._input.LA(1)
                if not(((_la) & ~0x3f) == 0 and ((1 << _la) & 70368744210406) != 0):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 353
                self.match(pddlParser.NUMBER)
                self.state = 354
                self.operation()
                self.state = 355
                self.match(pddlParser.RP)
                pass

            elif la_ == 8:
                self.enterOuterAlt(localctx, 8)
                self.state = 357
                self.match(pddlParser.LP)
                self.state = 358
                _la = self._input.LA(1)
                if not(((_la) & ~0x3f) == 0 and ((1 << _la) & 70368744210406) != 0):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 359
                self.operation()
                self.state = 360
                self.operation()
                self.state = 361
                self.match(pddlParser.RP)
                pass

            elif la_ == 9:
                self.enterOuterAlt(localctx, 9)
                self.state = 363
                self.match(pddlParser.LP)
                self.state = 364
                _la = self._input.LA(1)
                if not(((_la) & ~0x3f) == 0 and ((1 << _la) & 70368744210406) != 0):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 365
                self.operation()
                self.state = 366
                self.match(pddlParser.NUMBER)
                self.state = 367
                self.match(pddlParser.RP)
                pass

            elif la_ == 10:
                self.enterOuterAlt(localctx, 10)
                self.state = 369
                self.match(pddlParser.LP)
                self.state = 370
                self.match(pddlParser.T__2)
                self.state = 371
                self.operation()
                self.state = 372
                self.match(pddlParser.RP)
                pass

            elif la_ == 11:
                self.enterOuterAlt(localctx, 11)
                self.state = 374
                self.match(pddlParser.LP)
                self.state = 375
                self.match(pddlParser.T__2)
                self.state = 376
                self.match(pddlParser.LP)
                self.state = 377
                self.predicatedVariables()
                self.state = 378
                self.match(pddlParser.RP)
                self.state = 379
                self.match(pddlParser.RP)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ProcessDefContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LP(self, i:int=None):
            if i is None:
                return self.getTokens(pddlParser.LP)
            else:
                return self.getToken(pddlParser.LP, i)

        def PROCESS(self):
            return self.getToken(pddlParser.PROCESS, 0)

        def NAME(self):
            return self.getToken(pddlParser.NAME, 0)

        def PARAMETERS(self):
            return self.getToken(pddlParser.PARAMETERS, 0)

        def RP(self, i:int=None):
            if i is None:
                return self.getTokens(pddlParser.RP)
            else:
                return self.getToken(pddlParser.RP, i)

        def typedVariable(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(pddlParser.TypedVariableContext)
            else:
                return self.getTypedRuleContext(pddlParser.TypedVariableContext,i)


        def precondition(self):
            return self.getTypedRuleContext(pddlParser.PreconditionContext,0)


        def effect(self):
            return self.getTypedRuleContext(pddlParser.EffectContext,0)


        def getRuleIndex(self):
            return pddlParser.RULE_processDef

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProcessDef" ):
                listener.enterProcessDef(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProcessDef" ):
                listener.exitProcessDef(self)




    def processDef(self):

        localctx = pddlParser.ProcessDefContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_processDef)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 383
            self.match(pddlParser.LP)
            self.state = 384
            self.match(pddlParser.PROCESS)
            self.state = 385
            self.match(pddlParser.NAME)
            self.state = 386
            self.match(pddlParser.PARAMETERS)
            self.state = 387
            self.match(pddlParser.LP)
            self.state = 391
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==42:
                self.state = 388
                self.typedVariable()
                self.state = 393
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 394
            self.match(pddlParser.RP)
            self.state = 396
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==35:
                self.state = 395
                self.precondition()


            self.state = 399
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==36:
                self.state = 398
                self.effect()


            self.state = 401
            self.match(pddlParser.RP)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EventDefContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LP(self, i:int=None):
            if i is None:
                return self.getTokens(pddlParser.LP)
            else:
                return self.getToken(pddlParser.LP, i)

        def EVENT(self):
            return self.getToken(pddlParser.EVENT, 0)

        def NAME(self):
            return self.getToken(pddlParser.NAME, 0)

        def PARAMETERS(self):
            return self.getToken(pddlParser.PARAMETERS, 0)

        def RP(self, i:int=None):
            if i is None:
                return self.getTokens(pddlParser.RP)
            else:
                return self.getToken(pddlParser.RP, i)

        def typedVariable(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(pddlParser.TypedVariableContext)
            else:
                return self.getTypedRuleContext(pddlParser.TypedVariableContext,i)


        def precondition(self):
            return self.getTypedRuleContext(pddlParser.PreconditionContext,0)


        def effect(self):
            return self.getTypedRuleContext(pddlParser.EffectContext,0)


        def getRuleIndex(self):
            return pddlParser.RULE_eventDef

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEventDef" ):
                listener.enterEventDef(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEventDef" ):
                listener.exitEventDef(self)




    def eventDef(self):

        localctx = pddlParser.EventDefContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_eventDef)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 403
            self.match(pddlParser.LP)
            self.state = 404
            self.match(pddlParser.EVENT)
            self.state = 405
            self.match(pddlParser.NAME)
            self.state = 406
            self.match(pddlParser.PARAMETERS)
            self.state = 407
            self.match(pddlParser.LP)
            self.state = 411
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==42:
                self.state = 408
                self.typedVariable()
                self.state = 413
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 414
            self.match(pddlParser.RP)
            self.state = 416
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==35:
                self.state = 415
                self.precondition()


            self.state = 419
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==36:
                self.state = 418
                self.effect()


            self.state = 421
            self.match(pddlParser.RP)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ProblemContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LP(self):
            return self.getToken(pddlParser.LP, 0)

        def DEFINE(self):
            return self.getToken(pddlParser.DEFINE, 0)

        def problemDecl(self):
            return self.getTypedRuleContext(pddlParser.ProblemDeclContext,0)


        def problemDomain(self):
            return self.getTypedRuleContext(pddlParser.ProblemDomainContext,0)


        def init(self):
            return self.getTypedRuleContext(pddlParser.InitContext,0)


        def goal(self):
            return self.getTypedRuleContext(pddlParser.GoalContext,0)


        def RP(self):
            return self.getToken(pddlParser.RP, 0)

        def objectDecl(self):
            return self.getTypedRuleContext(pddlParser.ObjectDeclContext,0)


        def metric(self):
            return self.getTypedRuleContext(pddlParser.MetricContext,0)


        def getRuleIndex(self):
            return pddlParser.RULE_problem

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProblem" ):
                listener.enterProblem(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProblem" ):
                listener.exitProblem(self)




    def problem(self):

        localctx = pddlParser.ProblemContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_problem)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 423
            self.match(pddlParser.LP)
            self.state = 424
            self.match(pddlParser.DEFINE)
            self.state = 425
            self.problemDecl()
            self.state = 426
            self.problemDomain()
            self.state = 428
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,30,self._ctx)
            if la_ == 1:
                self.state = 427
                self.objectDecl()


            self.state = 430
            self.init()
            self.state = 431
            self.goal()
            self.state = 433
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==22:
                self.state = 432
                self.metric()


            self.state = 435
            self.match(pddlParser.RP)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ProblemDeclContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LP(self):
            return self.getToken(pddlParser.LP, 0)

        def PROBLEM(self):
            return self.getToken(pddlParser.PROBLEM, 0)

        def NAME(self):
            return self.getToken(pddlParser.NAME, 0)

        def RP(self):
            return self.getToken(pddlParser.RP, 0)

        def getRuleIndex(self):
            return pddlParser.RULE_problemDecl

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProblemDecl" ):
                listener.enterProblemDecl(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProblemDecl" ):
                listener.exitProblemDecl(self)




    def problemDecl(self):

        localctx = pddlParser.ProblemDeclContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_problemDecl)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 437
            self.match(pddlParser.LP)
            self.state = 438
            self.match(pddlParser.PROBLEM)
            self.state = 439
            self.match(pddlParser.NAME)
            self.state = 440
            self.match(pddlParser.RP)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ProblemDomainContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LP(self):
            return self.getToken(pddlParser.LP, 0)

        def NAME(self):
            return self.getToken(pddlParser.NAME, 0)

        def RP(self):
            return self.getToken(pddlParser.RP, 0)

        def getRuleIndex(self):
            return pddlParser.RULE_problemDomain

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProblemDomain" ):
                listener.enterProblemDomain(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProblemDomain" ):
                listener.exitProblemDomain(self)




    def problemDomain(self):

        localctx = pddlParser.ProblemDomainContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_problemDomain)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 442
            self.match(pddlParser.LP)
            self.state = 443
            self.match(pddlParser.T__14)
            self.state = 444
            self.match(pddlParser.NAME)
            self.state = 445
            self.match(pddlParser.RP)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ObjectDeclContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LP(self):
            return self.getToken(pddlParser.LP, 0)

        def RP(self):
            return self.getToken(pddlParser.RP, 0)

        def sameTypeNamesList(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(pddlParser.SameTypeNamesListContext)
            else:
                return self.getTypedRuleContext(pddlParser.SameTypeNamesListContext,i)


        def getRuleIndex(self):
            return pddlParser.RULE_objectDecl

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterObjectDecl" ):
                listener.enterObjectDecl(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitObjectDecl" ):
                listener.exitObjectDecl(self)




    def objectDecl(self):

        localctx = pddlParser.ObjectDeclContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_objectDecl)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 447
            self.match(pddlParser.LP)
            self.state = 448
            self.match(pddlParser.T__15)
            self.state = 450 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 449
                self.sameTypeNamesList()
                self.state = 452 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==41):
                    break

            self.state = 454
            self.match(pddlParser.RP)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SameTypeNamesListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NAME(self, i:int=None):
            if i is None:
                return self.getTokens(pddlParser.NAME)
            else:
                return self.getToken(pddlParser.NAME, i)

        def getRuleIndex(self):
            return pddlParser.RULE_sameTypeNamesList

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSameTypeNamesList" ):
                listener.enterSameTypeNamesList(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSameTypeNamesList" ):
                listener.exitSameTypeNamesList(self)




    def sameTypeNamesList(self):

        localctx = pddlParser.SameTypeNamesListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_sameTypeNamesList)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 457 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 456
                self.match(pddlParser.NAME)
                self.state = 459 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==41):
                    break

            self.state = 461
            self.match(pddlParser.T__0)
            self.state = 462
            self.match(pddlParser.NAME)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InitContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LP(self):
            return self.getToken(pddlParser.LP, 0)

        def RP(self):
            return self.getToken(pddlParser.RP, 0)

        def initEl(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(pddlParser.InitElContext)
            else:
                return self.getTypedRuleContext(pddlParser.InitElContext,i)


        def getRuleIndex(self):
            return pddlParser.RULE_init

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInit" ):
                listener.enterInit(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInit" ):
                listener.exitInit(self)




    def init(self):

        localctx = pddlParser.InitContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_init)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 464
            self.match(pddlParser.LP)
            self.state = 465
            self.match(pddlParser.T__16)
            self.state = 469
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==22:
                self.state = 466
                self.initEl()
                self.state = 471
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 472
            self.match(pddlParser.RP)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InitElContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def nameLiteral(self):
            return self.getTypedRuleContext(pddlParser.NameLiteralContext,0)


        def equalLiteral(self):
            return self.getTypedRuleContext(pddlParser.EqualLiteralContext,0)


        def getRuleIndex(self):
            return pddlParser.RULE_initEl

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInitEl" ):
                listener.enterInitEl(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInitEl" ):
                listener.exitInitEl(self)




    def initEl(self):

        localctx = pddlParser.InitElContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_initEl)
        try:
            self.state = 476
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,35,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 474
                self.nameLiteral()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 475
                self.equalLiteral()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NameLiteralContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def atomicNameFormula(self):
            return self.getTypedRuleContext(pddlParser.AtomicNameFormulaContext,0)


        def LP(self):
            return self.getToken(pddlParser.LP, 0)

        def RP(self):
            return self.getToken(pddlParser.RP, 0)

        def getRuleIndex(self):
            return pddlParser.RULE_nameLiteral

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNameLiteral" ):
                listener.enterNameLiteral(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNameLiteral" ):
                listener.exitNameLiteral(self)




    def nameLiteral(self):

        localctx = pddlParser.NameLiteralContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_nameLiteral)
        try:
            self.state = 484
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,36,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 478
                self.atomicNameFormula()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 479
                self.match(pddlParser.LP)
                self.state = 480
                self.match(pddlParser.T__2)
                self.state = 481
                self.atomicNameFormula()
                self.state = 482
                self.match(pddlParser.RP)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AtomicNameFormulaContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LP(self):
            return self.getToken(pddlParser.LP, 0)

        def RP(self):
            return self.getToken(pddlParser.RP, 0)

        def NAME(self, i:int=None):
            if i is None:
                return self.getTokens(pddlParser.NAME)
            else:
                return self.getToken(pddlParser.NAME, i)

        def getRuleIndex(self):
            return pddlParser.RULE_atomicNameFormula

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAtomicNameFormula" ):
                listener.enterAtomicNameFormula(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAtomicNameFormula" ):
                listener.exitAtomicNameFormula(self)




    def atomicNameFormula(self):

        localctx = pddlParser.AtomicNameFormulaContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_atomicNameFormula)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 486
            self.match(pddlParser.LP)
            self.state = 488 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 487
                self.match(pddlParser.NAME)
                self.state = 490 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==41):
                    break

            self.state = 492
            self.match(pddlParser.RP)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EqualLiteralContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LP(self):
            return self.getToken(pddlParser.LP, 0)

        def atomicNameFormula(self):
            return self.getTypedRuleContext(pddlParser.AtomicNameFormulaContext,0)


        def NUMBER(self):
            return self.getToken(pddlParser.NUMBER, 0)

        def RP(self):
            return self.getToken(pddlParser.RP, 0)

        def getRuleIndex(self):
            return pddlParser.RULE_equalLiteral

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEqualLiteral" ):
                listener.enterEqualLiteral(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEqualLiteral" ):
                listener.exitEqualLiteral(self)




    def equalLiteral(self):

        localctx = pddlParser.EqualLiteralContext(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_equalLiteral)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 494
            self.match(pddlParser.LP)
            self.state = 495
            self.match(pddlParser.T__4)
            self.state = 496
            self.atomicNameFormula()
            self.state = 497
            self.match(pddlParser.NUMBER)
            self.state = 498
            self.match(pddlParser.RP)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class GoalContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LP(self, i:int=None):
            if i is None:
                return self.getTokens(pddlParser.LP)
            else:
                return self.getToken(pddlParser.LP, i)

        def RP(self, i:int=None):
            if i is None:
                return self.getTokens(pddlParser.RP)
            else:
                return self.getToken(pddlParser.RP, i)

        def goalDesc(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(pddlParser.GoalDescContext)
            else:
                return self.getTypedRuleContext(pddlParser.GoalDescContext,i)


        def getRuleIndex(self):
            return pddlParser.RULE_goal

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGoal" ):
                listener.enterGoal(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGoal" ):
                listener.exitGoal(self)




    def goal(self):

        localctx = pddlParser.GoalContext(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_goal)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 500
            self.match(pddlParser.LP)
            self.state = 501
            self.match(pddlParser.T__17)
            self.state = 502
            self.match(pddlParser.LP)
            self.state = 503
            self.match(pddlParser.T__1)
            self.state = 505 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 504
                self.goalDesc()
                self.state = 507 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==22):
                    break

            self.state = 509
            self.match(pddlParser.RP)
            self.state = 510
            self.match(pddlParser.RP)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class GoalDescContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def atomicNameFormula(self):
            return self.getTypedRuleContext(pddlParser.AtomicNameFormulaContext,0)


        def LP(self, i:int=None):
            if i is None:
                return self.getTokens(pddlParser.LP)
            else:
                return self.getToken(pddlParser.LP, i)

        def RP(self, i:int=None):
            if i is None:
                return self.getTokens(pddlParser.RP)
            else:
                return self.getToken(pddlParser.RP, i)

        def NUMBER(self):
            return self.getToken(pddlParser.NUMBER, 0)

        def NAME(self, i:int=None):
            if i is None:
                return self.getTokens(pddlParser.NAME)
            else:
                return self.getToken(pddlParser.NAME, i)

        def getRuleIndex(self):
            return pddlParser.RULE_goalDesc

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGoalDesc" ):
                listener.enterGoalDesc(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGoalDesc" ):
                listener.exitGoalDesc(self)




    def goalDesc(self):

        localctx = pddlParser.GoalDescContext(self, self._ctx, self.state)
        self.enterRule(localctx, 64, self.RULE_goalDesc)
        self._la = 0 # Token type
        try:
            self.state = 529
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,40,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 512
                self.atomicNameFormula()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 513
                self.match(pddlParser.LP)
                self.state = 514
                self.match(pddlParser.T__2)
                self.state = 515
                self.atomicNameFormula()
                self.state = 516
                self.match(pddlParser.RP)
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 518
                self.match(pddlParser.LP)
                self.state = 519
                _la = self._input.LA(1)
                if not(((_la) & ~0x3f) == 0 and ((1 << _la) & 1888) != 0):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 520
                self.match(pddlParser.LP)
                self.state = 522 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while True:
                    self.state = 521
                    self.match(pddlParser.NAME)
                    self.state = 524 
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if not (_la==41):
                        break

                self.state = 526
                self.match(pddlParser.RP)
                self.state = 527
                self.match(pddlParser.NUMBER)
                self.state = 528
                self.match(pddlParser.RP)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MetricContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LP(self):
            return self.getToken(pddlParser.LP, 0)

        def atomicNameFormula(self):
            return self.getTypedRuleContext(pddlParser.AtomicNameFormulaContext,0)


        def RP(self):
            return self.getToken(pddlParser.RP, 0)

        def getRuleIndex(self):
            return pddlParser.RULE_metric

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMetric" ):
                listener.enterMetric(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMetric" ):
                listener.exitMetric(self)




    def metric(self):

        localctx = pddlParser.MetricContext(self, self._ctx, self.state)
        self.enterRule(localctx, 66, self.RULE_metric)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 531
            self.match(pddlParser.LP)
            self.state = 532
            self.match(pddlParser.T__18)
            self.state = 533
            _la = self._input.LA(1)
            if not(_la==20 or _la==21):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 534
            self.atomicNameFormula()
            self.state = 535
            self.match(pddlParser.RP)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





